import logging

import azure.functions as func
from bson.objectid import ObjectId

from ..shared.helpers import get_db


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Try updating task {0}'.format(req.route_params.get('id')))

    db = get_db()
    collection = db['tasks']

    collection.update_one({ '_id': ObjectId(req.route_params.get('id'))}, { '$set': { "status": req.get_json()['status']}});

    return func.HttpResponse(status_code=204)
