import azure.functions as func

from pymongo import MongoClient 
import base64
import json
 
def get_db():
    uri = "YOUR-MONGODB-CONNECTION-STRING-HERE"
    client = MongoClient(uri)
    db = client['workshop']

    return db 

def get_user(req: func.HttpRequest):
   principal = req.headers.get('x-ms-client-principal')
   user = base64.b64decode(principal)

   return json.loads(user.decode('utf-8'))