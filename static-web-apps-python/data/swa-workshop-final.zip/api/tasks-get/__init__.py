import logging
import json

import azure.functions as func

from ..shared.helpers import get_db, get_user

def main(req: func.HttpRequest) -> func.HttpResponse:

    user = get_user(req)

    logging.info(user)

    db = get_db()
    collection = db['tasks']
    o = collection.find({
        "userId": user["userId"]
    })

    myList = [task for task in o]

    return func.HttpResponse(json.dumps(myList, default=str), mimetype='application/json')
