import azure.functions as func
import json

from ..shared.helpers import get_db, get_user

def main(req: func.HttpRequest) -> func.HttpResponse:

    user = get_user(req)

    task = {
        "label": req.get_json()["label"],
        "status": "",
        "userId": user["userId"]
    }

    db = get_db()
    collection = db['tasks']
    collection.insert(task)

    return func.HttpResponse(json.dumps(task, default=str), mimetype='application/json')
